package xshop.data;

import xshop.entity.Category;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DataTransfer{
	public static int id;
	public static String message;
}